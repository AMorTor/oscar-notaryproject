import { NgModule } from '@angular/core';

import { CardModule } from 'primeng/card';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { AvatarModule } from 'primeng/avatar';
import { AvatarGroupModule } from 'primeng/avatargroup';
import { TableModule } from 'primeng/table';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToolbarModule } from 'primeng/toolbar';
import { CheckboxModule } from 'primeng/checkbox';
import { TagModule } from 'primeng/tag';
import { CalendarModule } from 'primeng/calendar';
import { InputMaskModule } from 'primeng/inputmask';
import { DropdownModule } from 'primeng/dropdown';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@NgModule({
  exports: [
    CardModule,
    InputTextModule,
    PasswordModule,
    ButtonModule,
    ToastModule,
    AvatarModule,
    AvatarGroupModule,
    ButtonModule,
    TableModule,
    ButtonModule,
    ToastModule,
    ConfirmDialogModule,
    ToolbarModule,
    InputTextModule,
    TableModule,
    CheckboxModule,
    TagModule,
    CalendarModule,
    InputMaskModule,
    DropdownModule,
    RadioButtonModule,
    InputSwitchModule,
    ProgressSpinnerModule
  ]
})
export class SharedModule {
}
