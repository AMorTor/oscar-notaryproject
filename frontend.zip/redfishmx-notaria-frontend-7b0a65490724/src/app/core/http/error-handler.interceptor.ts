import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { catchError } from 'rxjs/operators';
import { AuthCoreService } from '../services/auth-core.service';

@Injectable()
export class ErrorHandlerInterceptor implements HttpInterceptor {

  constructor(private authcore: AuthCoreService) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(catchError(error => this.errorHandler(error)));
  }

  private errorHandler(response: HttpEvent<any>): Observable<HttpEvent<any>> {
    //console.log(response);
    // @ts-ignore
    if (response.error && response.error.error_description && response.error.error_description === 'Bad credentials') {
      // @ts-ignore
      response.error.error_description = 'Usuario/contraña incorrecto';
    }
    // @ts-ignore
    if (response.error && response.error.error_description && response.error.error_description.includes('Access token expired')) {
      console.log('Access token expired');
      this.authcore.relogin().subscribe((value) => {
        //console.log(value);
        location.reload();
      }, error => {
        if (error && error.error_description && error.error.error_description.includes('Invalid refresh token (expired)')) {
          console.log('Invalid refresh token (expired)');
          setTimeout(() => {
            this.authcore.signOut();
          }, 1200);
        }
      });
    } else
      // @ts-ignore
      if(response.error) {
        console.log(response);
    }
    // @ts-ignore
    throw response.error;
  }



}
