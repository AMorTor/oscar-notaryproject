import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor, HttpHeaders
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Token } from '../models';

@Injectable()
export class ApiInterceptor implements HttpInterceptor {

  constructor() {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if (!/^(http|https):/i.test(request.url)) {
      if (request.url.includes('/oauth/token') || request.url.includes('/access-control/password-recovery')) {
        request = request.clone({
          headers: this.setBasicAuth()
        });
      } else if(!request.url.includes('/access-control/new-password')) {
        request = request.clone({ headers: this.setBearerToken() });
      }
      request = request.clone({ url: environment.apiUrl + request.url });
    }
    return next.handle(request);
  }

  setBasicAuth(): HttpHeaders {
    const credentials = btoa('angularapp' + ':' + '12345');

    const httpHeaders = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: 'Basic ' + credentials
    });
    return httpHeaders;
  }

  setBearerToken(): HttpHeaders {
    // @ts-ignore
    const token: Token = JSON.parse(sessionStorage.getItem('token'));

    const httpHeaders = new HttpHeaders({
      Authorization: 'Bearer ' + token.access_token
    });
    return httpHeaders;

  }

}
