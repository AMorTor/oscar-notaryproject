export interface ChangePassReq {
  newPassword: string;
  user: string;
  tx?: string;
}
