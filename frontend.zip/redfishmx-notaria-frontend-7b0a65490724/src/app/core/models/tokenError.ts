export interface TokenError {
  error: string;
  error_description: string;
}
