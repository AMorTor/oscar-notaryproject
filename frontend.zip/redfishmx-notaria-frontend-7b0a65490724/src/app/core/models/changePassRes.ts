export interface ChangePassRes {
  mensaje: string;
  customer: null;
}
