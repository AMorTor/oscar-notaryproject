import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Token } from '../models';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthCoreService {

  constructor(private http: HttpClient, private router: Router) { }

  relogin(): Observable<any>{

    const credentials = btoa('angularapp' + ':' + '12345');
    const httpHeaders = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Basic ' + credentials
    });

    const params = new URLSearchParams();
    params.set('grant_type', 'refresh_token');
    params.set('refresh_token', this.getRefreshToken());
    return this.http.post<Token>(environment.apiUrl + '/oauth/token', params.toString(), {headers: httpHeaders})
      .pipe(map(res => {
        console.log(res);
        sessionStorage.setItem('token', JSON.stringify(res));
      }));
  }

  // @ts-ignore
  getRefreshToken(): string {
    const token = sessionStorage.getItem('token');
    let refresh = '';
    if (token != null) {
      const tokenModel: Token = JSON.parse(token);
      refresh = tokenModel.refresh_token;
    }
    return refresh;
  }

  signOut(): void {
    sessionStorage.clear();
    this.router.navigate(['/auth/login']);
  }
}
