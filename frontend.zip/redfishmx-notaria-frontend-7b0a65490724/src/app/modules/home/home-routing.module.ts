import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { HomeGuard } from './guards/home.guard';
import { ConfigurationComponent } from './pages/configuration/configuration.component';
import { NotificationsComponent } from './pages/notifications/notifications.component';

const routes: Routes = [
  {
    path: '', component: HomeComponent, canActivate: [HomeGuard],
    children: [
      { path: '', component: WelcomeComponent },
      { path: 'configuration', component: ConfigurationComponent },
      { path: 'notifications', component: NotificationsComponent },
      { path: 'admin', loadChildren: () => import('../system-admin/system-admin.module').then(m => m.SystemAdminModule) },
      { path: 'notary', loadChildren: () => import('../notary/notary.module').then(m => m.NotaryModule) },
      { path: '**', redirectTo: '' }
    ]
  }
];

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(routes)
  ]
})
export class HomeRoutingModule { }
