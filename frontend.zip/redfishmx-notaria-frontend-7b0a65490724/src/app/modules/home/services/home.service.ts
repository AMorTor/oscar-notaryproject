import { Injectable } from '@angular/core';
import { Token } from '../../../core/models';
import { Router } from '@angular/router';
import { Observable, Subject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  private option = new Subject<any>();

  constructor(private router: Router) { }

  isAuthenticated(): boolean {
    const token = sessionStorage.getItem('token');
    return (token !== 'null' && token !== null);
  }

  isChangePassword(): boolean {
    const token = sessionStorage.getItem('token');
    let change = false;
    if (token != null) {
      const tokenModel: Token = JSON.parse(token);
      change = (tokenModel.changePass !== null && tokenModel.changePass !== false) ? true : false;
    }
    return change;
  }

  signOut(): void {
    sessionStorage.clear();
    this.router.navigate(['/auth/login']);
  }

  getActions(): any[] {
    const empty: string[] = [];
    const token = sessionStorage.getItem('token');
    return token != null ? (JSON.parse(token) as Token).actions : empty;
  }

  getUserName(): string {
    const token = sessionStorage.getItem('token');
    return token != null ? (JSON.parse(token) as Token).user_name.split('@')[0] : '';
  }

  getRole(): string {
    const token = sessionStorage.getItem('token');
    return token != null ? (JSON.parse(token) as Token).jti : '';
  }

  setOption(init: number): void {
    this.option.next(init);
  }

  getOption(): Observable<number> {
    return this.option.asObservable();
  }
}
