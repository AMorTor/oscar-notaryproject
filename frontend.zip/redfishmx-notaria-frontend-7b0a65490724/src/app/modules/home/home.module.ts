import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { HomeComponent } from './pages/home/home.component';
import { RouterModule } from '@angular/router';
import { HomeRoutingModule } from './home-routing.module';
import { NavbarComponent } from './components/navbar/navbar.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { ConfigurationComponent } from './pages/configuration/configuration.component';
import { NotificationsComponent } from './pages/notifications/notifications.component';
import { SharedModule } from '../../shared/shared.module';


@NgModule({
  declarations: [WelcomeComponent, HomeComponent, NavbarComponent, SidebarComponent, ConfigurationComponent, NotificationsComponent],
  imports: [
    CommonModule,
    RouterModule,
    HomeRoutingModule,
    SharedModule
  ]
})
export class HomeModule {
}
