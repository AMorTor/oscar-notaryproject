import { Component, OnInit } from '@angular/core';
import { HomeService } from '../../services/home.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Option } from '../../models';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  subscription: Subscription;
  // @ts-ignore
  selected: number;

  options: Option [] = [];

  allActions: Option [] = [
    {position: 1, id: 1, description: "Inicio", route: "/home" },
    {position: 2, id: 2, description: "Administración", route: "/home/notary" },
    {position: 2, id: 10, description: "Administración", route: "/home/admin/users-admin" },
    {position: 3, id: 3, description: "Búsqueda", route: "/home/notary/search" },
    {position: 4, id: 4, description: "Clientes", route: "/home/notary/clients" },
    {position: 5, id: 5, description: "Info", route: "/home/notary/info" },
    {position: 6, id: 6, description: "Configuración", route: "/home/configuration" },
    {position: 7, id: 7, description: "Autorizaciones", route: "/home/notary/info" },// TODO: Desarrollar componente Autorizaciones
    {position: 8, id: 8, description: "Notificaciones", route: "/home/notary/info" },// TODO: Desarrollar componente Notificaciones
    {position: 9, id: 9, description: "Documentos", route: "/home/notary/info" },// TODO: Desarrollar componente Documentos
  ]

  constructor(private service: HomeService, private router: Router) {
    this.subscription = this.service.getOption().subscribe((op) => {
      this.selected = op;
    });
  }

  ngOnInit(): void {
    this.getMenuOptions();
  }

  compareOptions(optA: Option, optB: Option): number {
    if(optA.position && optB.position) {
      return optA.position > optB.position ? 1 : optA.position < optB.position ? -1 : 0;
    }
    return 0;
  }

  getMenuOptions(): void {
    this.service.getActions().forEach(action => {
      this.allActions.forEach(availableAction => {
        if(availableAction.id == action.id){
          this.options.push(availableAction);
        }
      });
    });
    if(this.options.length > 0) {
      this.options.sort(this.compareOptions);
      this.service.setOption(this.getUrlOption(this.options));
    }
  }

  getUrlOption(options: Option[]): number {
    const url = this.router.url;
    let option = 0;
    options.forEach((item, i) => {
      if (url.includes(item.route)) {
        option = i;
      }
    });
    return option;
  }


  selectSection(select: number, route: string): void {
    this.selected = select;
    this.router.navigate([route]);
  }

}
