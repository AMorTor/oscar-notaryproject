import { Component, OnInit } from '@angular/core';
import { SystemService } from '../../../services/system.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { SystemDetail } from '../../../models';
import { MessageService, PrimeNGConfig } from "primeng/api";

@Component({
  selector: 'app-view-system',
  templateUrl: './view-system.component.html',
  styleUrls: ['./view-system.component.scss']
})
export class ViewSystemComponent implements OnInit {

  // @ts-ignore
  user: SystemDetail;

  constructor(private systemServ: SystemService, private route: ActivatedRoute, private router: Router,
              private messageService: MessageService, private primengConfig: PrimeNGConfig) { }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.route.queryParams.subscribe((params: Params) => {
      if (Object.keys(params).length > 0 && params.id !== '') {
        this.systemServ.getUserDetail(params.id).subscribe((res) => {
          this.user = res;
        }, error => {
          if (error.error_description.includes('Access token expired')) {
            this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
          }
        });
      } else {
        this.router.navigate(['/home/admin/system']);
      }
    });
  }

}
