import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Permission, Role, SystemDetail, SystemRequest } from '../../../models';
import { SystemService } from '../../../services/system.service';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-edit-system',
  templateUrl: './edit-system.component.html',
  styleUrls: ['./edit-system.component.scss']
})
export class EditSystemComponent implements OnInit {

  name = new FormControl(null, [
    Validators.required
  ]);
  email = new FormControl(null, [
    Validators.required,
    Validators.email
  ]);
  emailConfirm = new FormControl(null, [
    Validators.required
  ]);
  role = new FormControl(null, [
    Validators.required
  ]);
  permissions = new FormControl(null, [
    Validators.required
  ]);

  roles: Role[] = [];
  permission: Permission[] = [];
  permissionSelected: Permission[] = [];
  userForm: FormGroup;
  // @ts-ignore
  user: SystemDetail;
  // @ts-ignore
  userId: number;

  constructor(private userServ: SystemService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private router: Router, private form: FormBuilder, private route: ActivatedRoute) {
    this.userForm = this.form.group({
      name: this.name,
      email: this.email,
      emailConfirm: this.emailConfirm,
      role: this.role,
      permissions: this.permissions
    }, { validators: this.checkEmail });
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;

    this.route.queryParams.subscribe((params: Params) => {
      if (Object.keys(params).length > 0 && params.id !== '') {
        this.userId = params.id;
        this.userServ.getUserDetail(params.id).subscribe((u) => {
          this.userServ.getRoles().subscribe((rol) => {
            this.userServ.getPermissions().subscribe((per) => {
              this.permission = per;
              this.roles = rol;
              this.user = u;
              this.setValuesForm(this.user);
            });
          });
        }, error => {
          if (error.error_description.includes('Access token expired')) {
            this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
          }
        });
      } else {
        this.router.navigate(['/home/admin/clients']);
      }
    });

  }

  setValuesForm(user: SystemDetail): void {
    this.name.setValue(user.name);
    this.email.setValue(user.email);
    this.emailConfirm.setValue(user.email);
    this.role.setValue((this.roles.filter((item) => item.name === user.role[0]))[0]);
    this.permissions.setValue(this.setPermisions(this.user.permissions));
  }

  setPermisions(userPermissions: string[]): Permission[] {
    this.permission.forEach((i) => {
      userPermissions.forEach((j) => {
        if (i.description === j){
          this.permissionSelected.push(i);
        }
      });
    });
    return this.permissionSelected;
  }

  // tslint:disable-next-line:typedef
  checkEmail(group: FormGroup) {
    // @ts-ignore
    const email = group.get('email').value;
    // @ts-ignore
    const emailConfirm = group.get('emailConfirm').value;
    return email === emailConfirm ? null : { notSame: true };
  }

  // tslint:disable-next-line:typedef
  update() {
    if (this.userForm.valid) {
      const user: SystemRequest = this.getClientRequest();
      this.userServ.updateSystem(this.userId, user).subscribe((response) => {
        this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: response.mensaje});
        setTimeout(() => {
          this.router.navigate(['/home/admin/system']);
        }, 1200);
      }, error => {
        if (error.error_description.includes('Access token expired')) {
          this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
        } else {
          this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description});
          console.log(error);
        }
      });
    }
  }

  getClientRequest(): SystemRequest {

    return {
      name: this.name.value,
      email: this.email.value,
      permissions: this.permissions.value,
      role: this.role.value,
      status: 'Activo'
    };
  }

}
