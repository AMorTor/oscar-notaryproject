import { Component, OnInit } from '@angular/core';
import { System } from '../../../models';
import { ConfirmationService, MessageService, PrimeNGConfig } from 'primeng/api';
import { SystemService } from '../../../services/system.service';

@Component({
  selector: 'app-system-list',
  templateUrl: './system-list.component.html',
  styleUrls: ['./system-list.component.scss']
})
export class SystemListComponent implements OnInit {

  // @ts-ignore
  loading: boolean;
  // @ts-ignore
  users: System[];

  constructor(private userServ: SystemService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private confirmationService: ConfirmationService) { }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.loading = true;

    this.userServ.getUsers('0', '10000').subscribe((res) => {
      this.users = res.content;
      this.loading = false;
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
      }
    });
  }

  searchValue($event: Event): string {
    return ($event.target as HTMLInputElement).value;
  }

}
