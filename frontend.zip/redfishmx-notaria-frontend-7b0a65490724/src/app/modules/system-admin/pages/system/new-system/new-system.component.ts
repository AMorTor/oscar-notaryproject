import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import { Router } from '@angular/router';
import { Role, Permission, ClientRequest, SystemRequest } from '../../../models';
import { SystemService } from '../../../services/system.service';

@Component({
  selector: 'app-new-system',
  templateUrl: './new-system.component.html',
  styleUrls: ['./new-system.component.scss']
})
export class NewSystemComponent implements OnInit {

  name = new FormControl(null, [
    Validators.required
  ]);
  email = new FormControl(null, [
    Validators.required,
    Validators.email
  ]);
  emailConfirm = new FormControl(null, [
    Validators.required
  ]);
  role = new FormControl(null, [
    Validators.required
  ]);
  // @ts-ignore
  permissions = new FormControl(this.permission, [
    Validators.required
  ]);

  roles: Role[] = [];
  permission: Permission[] = [];
  userForm: FormGroup;

  constructor(private userServ: SystemService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private router: Router, private form: FormBuilder) {

    this.userForm = this.form.group({
      name: this.name,
      email: this.email,
      emailConfirm: this.emailConfirm,
      role: this.role,
      permissions: this.permissions
    }, { validators: this.checkEmail });
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.userServ.getRoles().subscribe((res) => {
      this.roles = res;
      this.userServ.getPermissions().subscribe((per) => {
        this.permission = per;
      }, error => {
        if (error.error_description.includes('Access token expired')) {
          this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
        }
      });
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
      }
    });
  }

  // tslint:disable-next-line:typedef
  checkEmail(group: FormGroup) {
    // @ts-ignore
    const email = group.get('email').value;
    // @ts-ignore
    const emailConfirm = group.get('emailConfirm').value;
    return email === emailConfirm ? null : { notSame: true };
  }

  setPermission($event: Event): void {}

  // tslint:disable-next-line:typedef
  create() {
    const user: SystemRequest = this.getClientRequest();
    this.userServ.createSystem(user).subscribe((response) => {
      this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: response.mensaje});
      setTimeout(() => {
        this.router.navigate(['/home/admin/system']);
      }, 1200);
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
      } else {
        this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description});
        console.log(error);
      }
    });
  }

  getClientRequest(): SystemRequest {
    return {
      name: this.name.value,
      email: this.email.value,
      permissions: this.permissions.value,
      role: this.role.value,
      status: 'Activo'
    };
  }

}
