import { Component, OnInit } from '@angular/core';
import { ClientService } from '../../../services/client.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ClientDetail, ClientRequest, Permission, Service } from '../../../models';
import { MessageService, PrimeNGConfig } from "primeng/api";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.scss']
})
export class EditClientComponent implements OnInit {

  nameClient = new FormControl(null, [
    Validators.required
  ]);
  nameAdmin = new FormControl(null, [
    Validators.required
  ]);
  phone = new FormControl(null, [
    Validators.required,
  ]);
  email = new FormControl(null, [
    Validators.required,
    Validators.email
  ]);
  emailConfirm = new FormControl(null, [
    Validators.required
  ]);
  service = new FormControl(null, [
    Validators.required
  ]);
  image = new FormControl(null, [
    Validators.required
  ]);
  subscriptionDate = new FormControl(null, [
    Validators.required
  ]);

  selectedFileName: string = 'Selecciona una imagen';
  selectedFile?: File;

  clientForm: FormGroup;
  services: Service[] = [];
  servicesList: Service[] = [];
  servicesSelected: Service[] = [];
  // @ts-ignore
  client: ClientDetail;

  constructor(private servClient: ClientService, private route: ActivatedRoute, private form: FormBuilder,
              private router: Router, private messageService: MessageService, private primengConfig: PrimeNGConfig) {

    this.clientForm = this.form.group({
      nameClient: this.nameClient,
      nameAdmin: this.nameAdmin,
      phone: this.phone,
      email: this.email,
      emailConfirm: this.emailConfirm,
      service: this.service,
      // image: this.image,
      subscriptionDate: this.subscriptionDate
    }, { validators: this.checkEmail });
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;

    this.route.queryParams.subscribe((params: Params) => {
      if (Object.keys(params).length > 0 && params.id !== '') {
        this.servClient.getClientDetail(params.id).subscribe((res) => {
          this.servClient.getServices().subscribe((resp) => {
            this.client = res;
            this.servicesList = resp;
            this.setValuesForm(this.client);
          });
        }, error => {
          if (error.error_description.includes('Access token expired')) {
            this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
          } else {
            console.log(error);
          }
        });
      } else {
        this.router.navigate(['/home/sysadmin/clients']);
      }
    });
  }

  setValuesForm(client: ClientDetail): void {
    this.nameClient.setValue(client.nameClient);
    this.nameAdmin.setValue(client.nameNotary);
    this.phone.setValue(client.phone);
    this.email.setValue(client.email);
    this.emailConfirm.setValue(client.email);
    this.service.setValue(this.setServiceSelected(client.services));
    this.subscriptionDate.setValue(new Date(client.subscription));
  }

  // tslint:disable-next-line:typedef
  checkEmail(group: FormGroup) {
    // @ts-ignore
    const email = group.get('email').value;
    // @ts-ignore
    const emailConfirm = group.get('emailConfirm').value;
    return email === emailConfirm ? null : { notSame: true };
  }

  setServiceSelected(services: Service[]): Service[] {
    this.servicesList.forEach((i) => {
      services.forEach((j) => {
        if (i.description === j.description){
          this.servicesSelected.push(i);
        }
      });
    });
    return this.servicesSelected;
  }

  // tslint:disable-next-line:typedef
  update() {
    const client: ClientRequest = this.getClientRequest();
    this.servClient.updateClient(this.client.id, client).subscribe((response) => {
      this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: response.mensaje});
      setTimeout(() => {
        this.router.navigate(['/home/admin/clients']);
      }, 1200);
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
      } else {
        this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description});
        console.log(error);
      }
    });
  }

  getClientRequest(): ClientRequest {
    return {
      nameNotary: this.nameAdmin.value,
      nameClient: this.nameClient.value,
      phone: this.phone.value,
      email: this.email.value,
      subscription: this.getDateFormattRequest(),
      notification: true,
      services: this.service.value
    };
  }

  getDateFormattRequest(): string {
    // tslint:disable-next-line:max-line-length
    return this.subscriptionDate.value.getFullYear() + '-' + (((this.subscriptionDate.value.getMonth() + 1) < 10 ? '0' + (this.subscriptionDate.value.getMonth() + 1) : (this.subscriptionDate.value.getMonth() + 1)))  + '-' + (this.subscriptionDate.value.getDate() < 10 ? '0' + this.subscriptionDate.value.getDate() : this.subscriptionDate.value.getDate());
  }

}
