import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import { Router } from '@angular/router';
import { ClientRequest, Service } from '../../../models';
import { ClientService } from '../../../services/client.service';

@Component({
  selector: 'app-new-client',
  templateUrl: './new-client.component.html',
  styleUrls: ['./new-client.component.scss']
})
export class NewClientComponent implements OnInit {

  nameClient = new FormControl(null, [
    Validators.required
  ]);
  nameAdmin = new FormControl(null, [
    Validators.required
  ]);
  phone = new FormControl(null, [
    Validators.required,
  ]);
  email = new FormControl(null, [
    Validators.required,
    Validators.email
  ]);
  emailConfirm = new FormControl(null, [
    Validators.required
  ]);
  service = new FormControl(null, [
    Validators.required
  ]);
  image = new FormControl(null, [
    Validators.required
  ]);
  subscriptionDate = new FormControl(null, [
    Validators.required
  ]);

  selectedFileName: string = 'Selecciona una imagen';
  selectedFile?: File;

  clientForm: FormGroup;
  services: Service[] = [];
  servicesList: Service[] = [];

  constructor(private clientServ: ClientService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private router: Router, private form: FormBuilder) {
    this.clientForm = this.form.group({
      nameClient: this.nameClient,
      nameAdmin: this.nameAdmin,
      phone: this.phone,
      email: this.email,
      emailConfirm: this.emailConfirm,
      service: this.service,
      // image: this.image,
      subscriptionDate: this.subscriptionDate
    }, { validators: this.checkEmail });
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.clientServ.getServices().subscribe((res) => {
      this.servicesList = res;
    });
  }

  // tslint:disable-next-line:typedef
  checkEmail(group: FormGroup) {
    // @ts-ignore
    const email = group.get('email').value;
    // @ts-ignore
    const emailConfirm = group.get('emailConfirm').value;
    return email === emailConfirm ? null : { notSame: true };
  }


  onFileSelect(input: any) {
    if (input.files && input.files[0]) {
      let reader = new FileReader();
      reader.onload = (e: any) => {
        this.image = e.target.result;
      }
      reader.readAsDataURL(input.files[0]);
      // @ts-ignore
      this.selectedFile = input.files[0];
      this.selectedFileName = input.files[0] ?  input.files[0].name : 'Selecciona un archivo';
    }
  }


  setService($event: Event, serv: Service): void {
    // @ts-ignore
    if ($event.checked) {
      this.services.push(serv);
    } else {
      this.services.forEach( (item, index) => {
        if (item.id === serv.id) { this.services.splice(index, 1); }
      });
    }
    this.services.length > 0 ? this.service.setValue(this.services) : this.service.setValue(null);
  }

  // tslint:disable-next-line:typedef
  create() {
    const client: ClientRequest = this.getClientRequest();
    if (this.selectedFile) {
      this.clientServ.createClient(client).subscribe((response) => {
        this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: response.mensaje});
        setTimeout(() => {
          this.router.navigate(['/home/admin/clients']);
        }, 1200);
      }, error => {
        if (error.error_description.includes('Access token expired')) {
          this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
        } else {
          this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description});
          console.log(error);
        }
      });
    }
  }

  getClientRequest(): ClientRequest {

    return {
      nameNotary: this.nameClient.value,
      nameClient: this.nameAdmin.value,
      phone: this.phone.value,
      email: this.email.value,
      subscription: this.getDateFormattRequest(),
      notification: true,
      services: this.services
    };
  }

  getDateFormattRequest(): string {
    // tslint:disable-next-line:max-line-length
    return this.subscriptionDate.value.getFullYear() + '-' + (((this.subscriptionDate.value.getMonth() + 1) < 10 ? '0' + (this.subscriptionDate.value.getMonth() + 1) : (this.subscriptionDate.value.getMonth() + 1)))  + '-' + (this.subscriptionDate.value.getDate() < 10 ? '0' + this.subscriptionDate.value.getDate() : this.subscriptionDate.value.getDate());
  }

}
