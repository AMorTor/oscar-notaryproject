import { Component, OnInit } from '@angular/core';
import { MessageService, PrimeNGConfig, ConfirmationService } from 'primeng/api';
import { ClientService } from '../../../services/client.service';
import { Client } from '../../../models';


@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.scss']
})
export class ClientListComponent implements OnInit {

  // @ts-ignore
  loading: boolean;
  // @ts-ignore
  clients: Client[];

  constructor(private servClient: ClientService, private messageService: MessageService, private primengConfig: PrimeNGConfig) { }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.loading = true;

    this.servClient.getClients('0', '10000').subscribe((res) => {
      this.clients = res.content;
      this.loading = false;
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
      }
    });
  }

  searchValue($event: Event): string {
    return ($event.target as HTMLInputElement).value;
  }

}
