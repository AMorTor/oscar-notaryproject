import { Component, OnInit } from '@angular/core';
import { ClientService } from '../../../services/client.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ClientDetail } from '../../../models';
import { MessageService, PrimeNGConfig } from "primeng/api";

@Component({
  selector: 'app-view-client',
  templateUrl: './view-client.component.html',
  styleUrls: ['./view-client.component.scss']
})
export class ViewClientComponent implements OnInit {

  // @ts-ignore
  client: ClientDetail;
  // @ts-ignore
  confirm: string;

  constructor(private servClient: ClientService, private route: ActivatedRoute, private router: Router,
              private messageService: MessageService, private primengConfig: PrimeNGConfig) { }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.route.queryParams.subscribe((params: Params) => {
      if (Object.keys(params).length > 0 && params.id !== '') {
       this.servClient.getClientDetail(params.id).subscribe((res) => {
         this.client = res;
       }, error => {
         if (error.error_description.includes('Access token expired')) {
           this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
         } else {
           console.log(error);
         }
       });
      } else {
        this.router.navigate(['/home/admin/clients']);
      }
    });
  }

  updateStatus(): void {
    this.servClient.updateStatusClient(this.client.id).subscribe((res) => {
      this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: res.mensaje});
      setTimeout(() => {
        this.router.navigate(['/home/admin/clients']);
      }, 1200);
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired' });
      } else {
        this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description});
        console.log(error);
      }
    });
  }

}
