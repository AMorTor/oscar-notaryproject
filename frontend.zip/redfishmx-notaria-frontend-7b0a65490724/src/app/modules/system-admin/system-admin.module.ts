import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SystemAdminRoutingModule } from './system-admin-routing.module';
import { UsersManagementComponent } from './pages/users-management/users-management.component';
import { ClientListComponent } from './pages/clients/client-list/client-list.component';
import { NewClientComponent } from './pages/clients/new-client/new-client.component';
import { EditClientComponent } from './pages/clients/edit-client/edit-client.component';
import { ViewClientComponent } from './pages/clients/view-client/view-client.component';
import { SystemListComponent } from './pages/system/system-list/system-list.component';
import { NewSystemComponent } from './pages/system/new-system/new-system.component';
import { EditSystemComponent } from './pages/system/edit-system/edit-system.component';
import { ViewSystemComponent } from './pages/system/view-system/view-system.component';
import { ClientService } from './services/client.service';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { ApiInterceptor } from '../../core/http/api.interceptor';
import { ErrorHandlerInterceptor } from '../../core/http/error-handler.interceptor';
import { SystemService } from './services/system.service';

import { ConfirmationService, MessageService, PrimeNGConfig } from 'primeng/api';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
  declarations: [
    UsersManagementComponent,
    ClientListComponent,
    NewClientComponent,
    EditClientComponent,
    ViewClientComponent,
    SystemListComponent,
    NewSystemComponent,
    EditSystemComponent,
    ViewSystemComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule,
    SystemAdminRoutingModule,
    FormsModule,
    SharedModule
  ],
  providers: [
    MessageService,
    PrimeNGConfig,
    ConfirmationService,
    ClientService,
    SystemService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ApiInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorHandlerInterceptor,
      multi: true
    }
  ]
})
export class SystemAdminModule {
}
