import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ClientDetail, ClientRequest, Clients, Service } from '../models';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private http: HttpClient) {}

  getClients(page: string, size: string): Observable<Clients> {
    let params = new HttpParams();
    params = params.append('pageNumber', page);
    params = params.append('pageSize', size);
    return this.http.get<Clients>('/notary/page', {params});
  }

  getClientDetail(id: string): Observable<ClientDetail> {
    return this.http.get<ClientDetail>('/notary/' + id);
  }

  getServices(): Observable<Service[]> {
    return this.http.get<Service[]>('/notary/catalogue/services');
  }

  createClient(client: ClientRequest): Observable<any> {
    return this.http.post<any>('/notary', client);
  }

  updateClient(id: number, client: ClientRequest): Observable<any> {
    return this.http.put<any>('/notary/' + id, client);
  }

  updateStatusClient(id: number): Observable<any> {
    // @ts-ignore
    return this.http.patch<any>('/notary/' + id);
  }
}
