export interface Permission {
  id: number;
  description: string;
}
