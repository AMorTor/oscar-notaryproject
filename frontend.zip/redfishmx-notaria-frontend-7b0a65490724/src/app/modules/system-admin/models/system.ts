export interface System {
  id: number;
  name: string;
  role: string[];
  email: string;
  status: string;
  isDeleted?: boolean;
}
