import { Service } from './service';

export interface ClientRequest {
  nameNotary: string;
  nameClient: string;
  phone: string;
  email: string;
  subscription: string;
  notification: boolean;
  services: Service[];
}
