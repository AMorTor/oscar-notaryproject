import { Permission } from './permission';
import { Role } from './role';

export interface SystemRequest {
  email: string;
  name: string;
  permissions: Permission[];
  role: Role;
  status?: string;
  isDeleted?: boolean;
}
