import { System } from './system';

export interface Systems {
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  totalElements: number;
  content: System[];
}
