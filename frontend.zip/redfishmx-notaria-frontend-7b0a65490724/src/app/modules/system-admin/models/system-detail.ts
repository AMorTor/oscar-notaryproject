export interface SystemDetail {
  name: string;
  email: string;
  role: string[];
  permissions: string[];
}
