export interface Client {
  id: number;
  clientName: string;
  email: string;
  status: string;
  notaryName: string;
}
