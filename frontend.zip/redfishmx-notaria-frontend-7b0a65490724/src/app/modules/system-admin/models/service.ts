export interface Service {
  id: string;
  description: string;
}
