import { Service } from './service';

export interface ClientDetail {
  id: number;
  nameNotary: string;
  nameClient: string;
  phone: string;
  email: string;
  services: Service[];
  subscription: Date;
  notification: boolean;
  status: boolean;
}
