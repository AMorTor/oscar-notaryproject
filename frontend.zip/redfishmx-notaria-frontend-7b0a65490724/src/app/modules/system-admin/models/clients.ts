import { Client } from './client';

export interface Clients {
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  totalElements: number;
  content: Client[];
}
