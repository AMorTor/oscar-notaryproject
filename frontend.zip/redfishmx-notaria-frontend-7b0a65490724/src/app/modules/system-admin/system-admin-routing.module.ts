import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsersManagementComponent } from './pages/users-management/users-management.component';
import { ClientListComponent } from './pages/clients/client-list/client-list.component';
import { NewClientComponent } from './pages/clients/new-client/new-client.component';
import { EditClientComponent } from './pages/clients/edit-client/edit-client.component';
import { ViewClientComponent } from './pages/clients/view-client/view-client.component';
import { SystemListComponent } from './pages/system/system-list/system-list.component';
import { NewSystemComponent } from './pages/system/new-system/new-system.component';
import { EditSystemComponent } from './pages/system/edit-system/edit-system.component';
import { ViewSystemComponent } from './pages/system/view-system/view-system.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'users-admin', component: UsersManagementComponent },
      { path: 'clients', component: ClientListComponent },
      { path: 'new-client', component: NewClientComponent },
      { path: 'edit-client', component: EditClientComponent },
      { path: 'view-client', component: ViewClientComponent },
      { path: 'system', component: SystemListComponent },
      { path: 'new-system', component: NewSystemComponent },
      { path: 'edit-system', component: EditSystemComponent },
      { path: 'view-system', component: ViewSystemComponent },
      { path: '', redirectTo: 'users-admin' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SystemAdminRoutingModule {
}
