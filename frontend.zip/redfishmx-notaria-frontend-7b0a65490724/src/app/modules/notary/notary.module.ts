import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NotaryRoutingModule } from './notary-routing.module';
import { UsersLIstComponent } from './pages/users/users-list/users-list.component';
import { NewUserComponent } from './pages/users/new-user/new-user.component';
import { EditUserComponent } from './pages/users/edit-user/edit-user.component';
import { ConfirmationService, MessageService, PrimeNGConfig } from 'primeng/api';
import { SharedModule } from '../../shared/shared.module';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { ApiInterceptor } from '../../core/http/api.interceptor';
import { ErrorHandlerInterceptor } from '../../core/http/error-handler.interceptor';
import { UsersService } from './services/users.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SearchComponent } from './pages/search/search.component';
import { ClientsListComponent } from './pages/clients/clients-list/clients-list.component';
import { NewClientComponent } from './pages/clients/new-client/new-client.component';
import { ClientsService } from './services/clients.service';
import { InfoComponent } from './pages/info/info.component';
import { EditClientComponent } from './pages/clients/edit-client/edit-client.component';
import { InfoClientComponent } from './pages/clients/info-client/info-client.component';
import { LegalActComponent } from './pages/clients/legal-act/legal-act.component';


@NgModule({
  declarations: [UsersLIstComponent, NewUserComponent, EditUserComponent, SearchComponent, ClientsListComponent, NewClientComponent, InfoComponent, EditClientComponent, InfoClientComponent, LegalActComponent],
    imports: [
        CommonModule,
        NotaryRoutingModule,
        SharedModule,
        HttpClientModule,
        ReactiveFormsModule,
        FormsModule
    ], providers: [
    MessageService,
    PrimeNGConfig,
    ConfirmationService,
    UsersService,
    ClientsService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ApiInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorHandlerInterceptor,
      multi: true
    }
  ]
})
export class NotaryModule { }
