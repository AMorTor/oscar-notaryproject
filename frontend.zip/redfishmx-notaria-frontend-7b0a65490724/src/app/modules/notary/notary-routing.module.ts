import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsersLIstComponent } from './pages/users/users-list/users-list.component';
import { NewUserComponent } from './pages/users/new-user/new-user.component';
import { EditUserComponent } from './pages/users/edit-user/edit-user.component';
import { SearchComponent } from './pages/search/search.component';
import { ClientsListComponent } from './pages/clients/clients-list/clients-list.component';
import { NewClientComponent } from './pages/clients/new-client/new-client.component';
import { InfoComponent } from './pages/info/info.component';
import { EditClientComponent } from './pages/clients/edit-client/edit-client.component';
import { InfoClientComponent } from './pages/clients/info-client/info-client.component';
import { LegalActComponent } from './pages/clients/legal-act/legal-act.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'users', component: UsersLIstComponent },
      { path: 'new-user', component: NewUserComponent },
      { path: 'edit-user', component: EditUserComponent },
      { path: 'search', component: SearchComponent },
      { path: 'clients', component: ClientsListComponent },
      { path: 'new-client', component: NewClientComponent },
      { path: 'edit-client', component: EditClientComponent },
      { path: 'info-client', component: InfoClientComponent },
      { path: 'add-legal', component: LegalActComponent },
      { path: 'info', component: InfoComponent },
      { path: '', redirectTo: 'users' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NotaryRoutingModule {
}
