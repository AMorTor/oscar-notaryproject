import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalActComponent } from './legal-act.component';

describe('LegalActComponent', () => {
  let component: LegalActComponent;
  let fixture: ComponentFixture<LegalActComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LegalActComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LegalActComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
