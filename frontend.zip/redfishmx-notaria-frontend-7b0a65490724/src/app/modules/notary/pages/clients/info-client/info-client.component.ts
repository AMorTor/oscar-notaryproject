import { Component, OnInit } from '@angular/core';
import { ClientsService } from '../../../services/clients.service';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Client } from '../../../models';

@Component({
  selector: 'app-info-client',
  templateUrl: './info-client.component.html',
  styleUrls: ['./info-client.component.scss']
})
export class InfoClientComponent implements OnInit {

  // @ts-ignore
  clientId: number;
  // @ts-ignore
  client: Client;

  constructor(private service: ClientsService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.primengConfig.ripple = true;

    this.route.queryParams.subscribe((params: Params) => {
      if (Object.keys(params).length > 0 && params.id !== '') {
        this.clientId = params.id;
        this.service.getClient(params.id).subscribe((c) => {
          this.client = c;
        }, error => {
          if (error.error_description.includes('Access token expired')) {
            this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired', life: 2500});
          }
        });
      } else {
        this.router.navigate(['/home/notary/clients']);
      }
    });
  }

}
