import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import { Router } from '@angular/router';
import { ClientRequest } from '../../../models';
import { ClientsService } from '../../../services/clients.service';

@Component({
  selector: 'app-new-client',
  templateUrl: './new-client.component.html',
  styleUrls: ['./new-client.component.scss']
})
export class NewClientComponent implements OnInit {

  name = new FormControl(null, [
    Validators.required
  ]);
  email = new FormControl(null, [
    Validators.required,
    Validators.email
  ]);
  emailConfirm = new FormControl(null, [
    Validators.required
  ]);
  phone = new FormControl(null, [
    Validators.required
  ]);
  userForm: FormGroup;

  constructor(private service: ClientsService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private router: Router, private form: FormBuilder) {

    this.userForm = this.form.group({
      name: this.name,
      email: this.email,
      emailConfirm: this.emailConfirm,
      phone: this.phone
    }, {validators: this.checkEmail});
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
  }

  // tslint:disable-next-line:typedef
  checkEmail(group: FormGroup) {
    // @ts-ignore
    const email = group.get('email').value;
    // @ts-ignore
    const emailConfirm = group.get('emailConfirm').value;
    return email === emailConfirm ? null : {notSame: true};
  }

  create(): void {
    const user: ClientRequest = this.getClientRequest();
    this.service.createClient(user).subscribe((response) => {
      this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: response.mensaje});
      setTimeout(() => {
        this.router.navigate(['/home/notary/clients']);
      }, 1200);
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired'});
      } else {
        this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description});
        console.log(error);
      }
    });
  }

  getClientRequest(): ClientRequest {
    return {
      name: this.name.value,
      email: this.email.value,
      phoneNumber: this.phone.value
    };
  }

}
