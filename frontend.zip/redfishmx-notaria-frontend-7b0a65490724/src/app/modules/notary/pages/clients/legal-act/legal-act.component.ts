import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-legal-act',
  templateUrl: './legal-act.component.html',
  styleUrls: ['./legal-act.component.scss']
})
export class LegalActComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
