import { Component, OnInit } from '@angular/core';
import { Client } from '../../../models';
import { ConfirmationService, MessageService, PrimeNGConfig } from 'primeng/api';
import { ClientsService } from '../../../services/clients.service';

@Component({
  selector: 'app-clients-list',
  templateUrl: './clients-list.component.html',
  styleUrls: ['./clients-list.component.scss']
})
export class ClientsListComponent implements OnInit {

  // @ts-ignore
  loading: boolean;
  // @ts-ignore
  clients: Client[];

  constructor(private service: ClientsService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private confirmationService: ConfirmationService) { }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.loading = true;

    this.service.getClients().subscribe((res) => {
      this.clients = res;
      this.loading = false;
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired', life: 2500});
      } else {
        console.log(error);
      }
    });
  }

  searchValue($event: Event): string {
    return ($event.target as HTMLInputElement).value;
  }

}
