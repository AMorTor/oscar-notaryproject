import { Component, OnInit } from '@angular/core';
import {System, SystemRequest} from '../../../../system-admin/models';
import { ConfirmationService, MessageService, PrimeNGConfig } from 'primeng/api';
import { UsersService } from '../../../services/users.service';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersLIstComponent implements OnInit {

  // @ts-ignore
  loading: boolean;
  // @ts-ignore
  users: System[];

  constructor(private service: UsersService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private confirmationService: ConfirmationService) {
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.loading = true;

    this.service.getUsers('0', '10000').subscribe((res) => {
      this.users = res.content;
      this.loading = false;
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Access token expired', life: 2500});
      } else {
        console.log(error);
      }
    });
  }

  searchValue($event: Event): string {
    return ($event.target as HTMLInputElement).value;
  }

  update(user: System) {
    const updatedUser: SystemRequest = {
      name: user.name,
      email: user.email,
      permissions: [],
      role: {id: 0, name: 'unknown'},
      status: user.status ? user.status : 'Active',
      isDeleted: user.isDeleted ? user.isDeleted : false
    }

    this.service.updateUser(user.id, updatedUser).subscribe( response => {
      this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: `Usuario ${user.status === 'Activo' ? 'Activado' : 'Desctivado'}`, life: 2500 });
      if (user.isDeleted) {
        this.users = this.users.filter(val => val.id !== user.id);
      }
    }, error => {
      if (error.error_description.includes('Access token expired')) {
        this.messageService.add({severity: 'error', summary: 'Error', detail: 'Su sesión ha expirado, vuelva a inciar sesión', life: 2500 });
      } else {
        this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description, life: 2500});
        console.log(error);
      }
    });
  }

  changeUserStatus(user: System): void {
    this.confirmationService.confirm({
      message: `¿Seguro que quiere ${user.status === 'Activo' ? 'DESACTIVAR' : 'ACTIVAR'}  al usuario: ${user.name} ?`,
      header: 'Alerta de acción',
      icon: 'pi pi-exclamation-triangle',
      //acceptButtonStyleClass: 'p-button-success',
      rejectButtonStyleClass: 'p-button-danger',
      acceptLabel: 'Aceptar',
      rejectLabel: 'Cancelar',
      accept: () => {
        user.status = user.status === 'Activo' ? 'Inactivo' : 'Activo';
        this.update(user);
      }
    });
  }

  deleteUser(user: System): void {
    this.confirmationService.confirm({
      message: 'Seguro que quieres eliminar al usuario: ' + user.name + '?',
      header: 'Alerta de acción',
      icon: 'pi pi-exclamation-triangle',
      //acceptButtonStyleClass: 'p-button-success',
      rejectButtonStyleClass: 'p-button-danger',
      acceptLabel: 'Aceptar',
      rejectLabel: 'Cancelar',
      accept: () => {
        user.isDeleted = true;
        this.update(user);
      }
    });
  }

}
