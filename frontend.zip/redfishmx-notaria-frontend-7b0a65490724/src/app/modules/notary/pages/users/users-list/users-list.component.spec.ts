import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersLIstComponent } from './users-list.component';

describe('UsersLIstComponent', () => {
  let component: UsersLIstComponent;
  let fixture: ComponentFixture<UsersLIstComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsersLIstComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersLIstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
