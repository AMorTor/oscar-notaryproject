import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Client, ClientRequest } from '../models';

@Injectable({
  providedIn: 'root'
})
export class ClientsService {

  constructor(private http: HttpClient) { }

  getClients(): Observable<Client[]> {
    return this.http.get<Client[]>('/client');
  }

  getClient(id: string): Observable<Client> {
    return this.http.get<Client>('/client/' + id);
  }

  createClient(client: ClientRequest): Observable<any> {
    return this.http.post<any>('/client', client);
  }

  updateClient(id: number, client: ClientRequest): Observable<any> {
    return this.http.put<any>('/client/' + id, client);
  }
}
