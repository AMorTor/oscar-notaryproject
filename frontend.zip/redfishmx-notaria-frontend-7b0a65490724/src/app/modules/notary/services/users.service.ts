import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Permission, Role, SystemDetail, SystemRequest, Systems } from '../../system-admin/models';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http: HttpClient) { }

  getUsers(page: string, size: string): Observable<Systems> {
    let params = new HttpParams();
    params = params.append('pageNumber', page);
    params = params.append('pageSize', size);
    return this.http.get<Systems>('/system-user/page', {params});
  }

  getUserDetail(id: string): Observable<SystemDetail> {
    return this.http.get<SystemDetail>('/system-user/' + id);
  }

  getRoles(): Observable<Role[]> {
    return this.http.get<Role[]>('/system-user/catalogue/roles');
  }

  getPermissions(): Observable<Permission[]> {
    return this.http.get<Permission[]>('/system-user/catalogue/permissions');
  }

  createUser(client: SystemRequest): Observable<any> {
    return this.http.post<any>('/system-user', client);
  }

  updateUser(id: number, client: SystemRequest): Observable<any> {
    return this.http.put<any>('/system-user/' + id, client);
  }
}
