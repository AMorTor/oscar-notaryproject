export interface ClientRequest {
  name: string;
  email: string;
  phoneNumber: string;
}
