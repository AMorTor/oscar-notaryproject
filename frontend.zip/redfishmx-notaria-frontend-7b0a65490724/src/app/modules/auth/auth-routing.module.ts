import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { RecoverUserComponent } from './pages/recover-user/recover-user.component';
import { ChangePasswordComponent } from './pages/change-password/change-password.component';
import { AuthGuard } from './guards/auth.guard';
import { PassGuard } from './guards/pass.guard';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'login', component: LoginComponent, canActivate: [AuthGuard] },
      { path: 'recover', component: RecoverUserComponent, canActivate: [AuthGuard] },
      { path: 'password', component: ChangePasswordComponent, canActivate: [PassGuard]},
      { path: '**', redirectTo: 'login' }
    ]
  }
];

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(routes)
  ]
})
export class AuthRoutingModule {
}
