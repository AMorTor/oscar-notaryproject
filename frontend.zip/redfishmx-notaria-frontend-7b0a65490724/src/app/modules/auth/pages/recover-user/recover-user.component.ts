import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import {Router} from "@angular/router";

@Component({
  selector: 'app-recover-user',
  templateUrl: './recover-user.component.html',
  styleUrls: ['./recover-user.component.scss']
})
export class RecoverUserComponent implements OnInit {

  emailFormControl = new FormControl(null, [
    Validators.required,
    Validators.email
  ]);

  recoverForm: FormGroup;

  constructor(private auth: AuthService, private messageService: MessageService,
              private primengConfig: PrimeNGConfig, private router: Router) {
    this.recoverForm = new FormGroup({
      emailFormControl: this.emailFormControl
    });
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
  }

  recover(): void {
    this.auth.recoverPassword(this.emailFormControl.value).subscribe( res => {
      this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: 'Se enviara un correo electronico a '
          + this.emailFormControl.value + ' con las instrucciones para recuperar su usuario'});
      setTimeout(() => {
        this.router.navigate(['/']);
      }, 5000);
      }, error => {
      console.log(error);
      this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description});
      }
    );
  }

}
