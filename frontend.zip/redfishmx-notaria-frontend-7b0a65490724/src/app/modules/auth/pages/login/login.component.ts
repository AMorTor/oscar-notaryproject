import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  unmasked = false;
  emailFormControl = new FormControl(null, [
    Validators.required,
    Validators.email
  ]);

  passwordFormControl = new FormControl(null, [
    Validators.required
  ]);

  userForm: FormGroup;

  constructor(private auth: AuthService, private messageService: MessageService, private primengConfig: PrimeNGConfig,
              private router: Router) {
    this.userForm = new FormGroup({
      emailFormControl: this.emailFormControl,
      passwordFormControl: this.passwordFormControl
    });
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
  }

  login(): void {
    this.auth.login(this.emailFormControl.value, this.passwordFormControl.value).subscribe((res) => {
      this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: 'Bienvenido'});
      setTimeout(() => {
        this.router.navigate([res]);
      }, 800);
    }, error => {
      console.log(error);
      this.messageService.add({severity: 'error', summary: 'Error', detail: error.error_description});
    });
  }

  onMaskToggle(): void {
    this.unmasked = !this.unmasked;
  }

  toggleIconClass(): string {
    return this.unmasked ? 'pi pi-eye-slash' : 'pi pi-eye';
  }

  inputType(): string {
    return this.unmasked ? 'text' : 'password';
  }

}
