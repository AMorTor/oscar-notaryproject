import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService, PrimeNGConfig } from 'primeng/api';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

  unmaskedPass = false;
  unmaskedConfirm = false;
  tx?: any;
  ux?: any;

  passwordFormControl = new FormControl(null, [
    Validators.required,
    Validators.pattern('(?!.*\\s)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%&?¿¡*+])[A-Za-z0-9\d!@#$%&?¿¡*+].{8,}')
  ]);

  passwordConfirmFormControl = new FormControl(null, [
    Validators.required
  ]);

  passwordForm: FormGroup;


  constructor(private auth: AuthService, private form: FormBuilder, private messageService: MessageService,
              private primengConfig: PrimeNGConfig, private router: Router, private activatedRoute: ActivatedRoute) {
    this.passwordForm = this.form.group({
      passwordFormControl: this.passwordFormControl,
      passwordConfirmFormControl: this.passwordConfirmFormControl
    }, { validators: this.checkPasswords });
  }

  ngOnInit(): void {
    this.primengConfig.ripple = true;
    this.activatedRoute.queryParams.subscribe(params => {
      this.tx = params['tx'];
    });
    this.activatedRoute.queryParams.subscribe(params => {
      this.ux = params['ux'];
    });
  }

  changePassword(): void {
    this.auth.changePassword(this.passwordFormControl.value, this.tx, this.ux).subscribe((res) => {
      if(this.tx && this.ux){
        this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: 'Es necesario que inicie sesión con su nueva contraseña para continuar'});
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 3000);
      } else {
        this.messageService.add({severity: 'success', summary: 'Acción exitosa', detail: res.mensaje});
        setTimeout(() => {
          this.router.navigate(['/home/welcome']);
        }, 800);
      }

    }, error => {
      console.log(error);
      this.messageService.add({severity: 'error', summary: 'Error', detail: error && error.error_description ? error.error_description : error ? error : 'LOL'});
    });
  }

  // tslint:disable-next-line:typedef
  checkPasswords(group: FormGroup) {
    // @ts-ignore
    const password = group.get('passwordFormControl').value;
    // @ts-ignore
    const confirmPassword = group.get('passwordConfirmFormControl').value;
    return password === confirmPassword ? null : { notSame: true };
  }

  onMaskTogglePass(): void {
    this.unmaskedPass = !this.unmaskedPass;
  }

  onMaskToggleConfirm(): void {
    this.unmaskedConfirm = !this.unmaskedConfirm;
  }

  toggleIconClassPass(): string {
    return this.unmaskedPass ? 'pi pi-eye-slash' : 'pi pi-eye';
  }

  toggleIconClassConfirm(): string {
    return this.unmaskedConfirm ? 'pi pi-eye-slash' : 'pi pi-eye';
  }

  inputTypePass(): string {
    return this.unmaskedPass ? 'text' : 'password';
  }

  inputTypeConfirm(): string {
    return this.unmaskedConfirm ? 'text' : 'password';
  }

}
