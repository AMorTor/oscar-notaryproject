import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {catchError, map, tap} from 'rxjs/operators';
import { ChangePassReq, ChangePassRes, Token } from '../../../core/models';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  login(user: string, password: string): Observable<any>{

    const params = new URLSearchParams();
    params.set('grant_type', 'password');
    params.set('username', user);
    params.set('password', password);
    return this.http.post<Token>('/oauth/token', params.toString())
      .pipe(map(res => {
      sessionStorage.setItem('token', JSON.stringify(res));
      return res.changePass ? (res.actions.length > 1 ? '/home/welcome' : '/home/notary/info') : '/auth/password';
    }));
  }

  changePassword(password: string, tx?: string, ux?: string): Observable<ChangePassRes> {
    if(!tx){
      // @ts-ignore
      const token: Token = JSON.parse(sessionStorage.getItem('token'));
      const user: ChangePassReq = {
        user: token.email,
        newPassword: password
      };

      return this.http.post<ChangePassRes>('/user/new-password', user)
        .pipe(map(res => {
          token.changePass = true;
          sessionStorage.setItem('token', JSON.stringify(token));
          return res;
        }));
    } else {
      const user: ChangePassReq = {
        // @ts-ignore
        user: ux,
        newPassword: password,
        tx: tx
      }
      return this.http.post<ChangePassRes>('/access-control/new-password', user)
        .pipe(map(res => {
          return res;
        }));
    }
  }

  isAuthenticated(): boolean {
    const token = sessionStorage.getItem('token');
    return (token !== 'null' && token !== null);
  }

  isChangePassword(): boolean {
    const token = sessionStorage.getItem('token');
    let change = false;
    if (token != null) {
      const tokenModel: Token = JSON.parse(token);
      change = (tokenModel.changePass !== null && tokenModel.changePass !== false) ? true : false;
    }
    return change;
  }

  recoverPassword(user: string): Observable<any>{
    let response = this.http.get('/access-control/password-recovery?user='+user)
      .pipe(map(res => {
          return res;
        })
      );
    return response;
  }

}
