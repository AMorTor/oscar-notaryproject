import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './pages/login/login.component';
import { AuthRoutingModule } from './auth-routing.module';
import { RecoverUserComponent } from './pages/recover-user/recover-user.component';
import { ChangePasswordComponent } from './pages/change-password/change-password.component';
import { AuthService } from './services/auth.service';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { ApiInterceptor } from '../../core/http/api.interceptor';
import { ErrorHandlerInterceptor } from '../../core/http/error-handler.interceptor';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { MessageService, PrimeNGConfig } from 'primeng/api';

@NgModule({
  declarations: [LoginComponent, RecoverUserComponent, ChangePasswordComponent],
  imports: [
    CommonModule,
    AuthRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule,
    SharedModule
  ],
  providers: [
    AuthService,
    MessageService,
    PrimeNGConfig,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ApiInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorHandlerInterceptor,
      multi: true
    }
  ]
})
export class AuthModule {
}
